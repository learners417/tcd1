import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  BookOpen,
  Loader2,
  Calendar,
  Flame,
  History,
  Check,
  Send,
  Zap,
  Activity,
  Brain,
  Heart,
  Award,
  Target,
  Scale,
  TrendingUp,
  HeartPulse,
  Moon,
  Salad,
  Dumbbell,
  Clock,
  Users,
  Lightbulb,
  CloudRain,
  UserX,
} from 'lucide-react';
import { supabase, isSupabaseReady, guardarFila } from '../lib/supabase';
import { reportError } from '../lib/errors';
import { toast } from 'sonner';
import { generateText } from '../lib/aiProvider';
import { usePersistedState } from '../lib/usePersistedState';
import {
  TAREAS_TAGS,
  CHECKEOS_CHIPS,
  LOGRO_MAX_CHARS,
  BLOQUEO_MAX_CHARS,
  calcularScore,
  indiceBienestar,
  focoNegocio,
  equilibrioIntegral,
  consistencia7d,
  energiaPromedio7d,
  rachaActiva,
  etiquetaEnergia,
  colorDimension,
  toFechaStr,
  type EntradaHistorica,
} from '../lib/diarioCalcs';

// ─── Tipos ────────────────────────────────────────────────────────────────────

interface EntradaDiario {
  id: string;
  fecha: string;
  energia: number; // 1-10
  cuerpo: number; // 1-10
  mente: number; // 1-10
  emociones: number; // 1-10
  logro: string;
  tareas: string[];
  checkeos: string[];
  bloqueo: string;
  score: number; // 0-100, server-side
}

interface ResumenSemana {
  id: string;
  semana_inicio: string;
  resumen_texto: string;
  created_at: string;
}

// Icono lucide por cada checkeo (sin emojis, según el sistema de diseño de la app)
const CHECKEO_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  durmio_bien: Moon,
  comio_bien: Salad,
  entreno: Dumbbell,
  tiempo_libre: Clock,
  conecto_alguien: Users,
  inspirado: Lightbulb,
  ansioso: CloudRain,
  solo: UserX,
};

const DIMENSIONES = [
  { key: 'cuerpo' as const, label: 'Cuerpo', icon: Activity },
  { key: 'mente' as const, label: 'Mente', icon: Brain },
  { key: 'emociones' as const, label: 'Emociones', icon: Heart },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getCurrentDay(): number {
  try {
    const profile = localStorage.getItem('tcd_profile');
    if (!profile) return 1;
    const parsed = JSON.parse(profile);
    const fechaInicio = parsed.fecha_inicio;
    if (!fechaInicio) return 1;
    const inicio = new Date(fechaInicio + 'T00:00:00');
    const ahora = new Date();
    return Math.floor((ahora.getTime() - inicio.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  } catch {
    return 1;
  }
}

function toHistorica(e: EntradaDiario): EntradaHistorica {
  return {
    fecha: e.fecha,
    energia: e.energia,
    cuerpo: e.cuerpo,
    mente: e.mente,
    emociones: e.emociones,
    score: e.score,
    bloqueo: e.bloqueo,
    tareas: e.tareas,
  };
}

// Mapea una fila cruda de Supabase (con fallbacks a campos legacy) → EntradaDiario
function mapRow(d: any): EntradaDiario {
  return {
    id: String(d.id),
    fecha: d.fecha,
    energia: d.energia_nivel ?? 5,
    cuerpo: d.diario_cuerpo ?? 0,
    mente: d.diario_mente ?? 0,
    emociones: d.diario_emociones ?? 0,
    logro: d.diario_logro ?? d.pensamiento_dominante ?? '',
    tareas: Array.isArray(d.diario_tareas) ? d.diario_tareas : [],
    checkeos: Array.isArray(d.diario_checkeos) ? d.diario_checkeos : [],
    bloqueo: d.diario_bloqueo ?? '',
    score: d.diario_score ?? 0,
  };
}

// ─── Escala 1–10 interactiva ───────────────────────────────────────────────────

/** Cinco toques con palabra — nadie sabe qué es un 7 sobre 10. */
const NIVELES_ENERGIA = [
  { valor: 2, emoji: '🪫', palabra: 'En cero' },
  { valor: 4, emoji: '😮‍💨', palabra: 'Bajo' },
  { valor: 6, emoji: '😐', palabra: 'Normal' },
  { valor: 8, emoji: '💪', palabra: 'Bien' },
  { valor: 10, emoji: '⚡', palabra: 'Encendido' },
];

function Escala10({
  valor,
  onChange,
  color,
}: {
  valor: number;
  onChange: (v: number) => void;
  color?: (v: number) => string;
}) {
  return (
    <div className="flex gap-1">
      {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => {
        const activo = n <= valor;
        const fill = color ? color(valor) : '#E8962E';
        return (
          <button
            key={n}
            type="button"
            onClick={() => onChange(n)}
            aria-label={`Nivel ${n}`}
            className="flex-1 h-7 rounded-md transition-all"
            style={{
              background: activo ? fill : 'rgba(232,150,46,0.08)',
            }}
          />
        );
      })}
    </div>
  );
}

// ─── KPI card (post-guardado) ──────────────────────────────────────────────────

function KpiCard({
  label,
  value,
  icon: Icon,
  tone = 'default',
  delta,
}: {
  label: string;
  value: string;
  icon: React.ComponentType<{ className?: string }>;
  tone?: 'default' | 'green' | 'warn';
  delta?: string;
}) {
  const valColor =
    tone === 'green' ? 'text-success' : tone === 'warn' ? 'text-[#E09040]' : 'text-cream';
  return (
    <div className="card-panel p-4 rounded-2xl border border-[rgba(232,150,46,0.12)]">
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon className="w-3.5 h-3.5 text-gold/60" />
        <p className="text-[11px] text-cream/55 uppercase tracking-widest font-semibold">{label}</p>
      </div>
      <p className={`text-xl font-medium ${valColor}`}>{value}</p>
      {delta && <p className="text-[11px] text-cream/55 mt-0.5">{delta}</p>}
    </div>
  );
}

// ─── Componente principal ──────────────────────────────────────────────────────

export default function DiarioDirector({
  userId,
}: {
  userId?: string;
}) {
  const [entries, setEntries] = useState<EntradaDiario[]>([]);
  const [cronoSegundos, setCronoSegundos] = useState(180);
  const [cronoActivo, setCronoActivo] = useState(false);
  const [masDetalle, setMasDetalle] = useState(false);
  useEffect(() => {
    if (!cronoActivo || cronoSegundos <= 0) return;
    const t = setInterval(() => setCronoSegundos((v) => Math.max(0, v - 1)), 1000);
    return () => clearInterval(t);
  }, [cronoActivo, cronoSegundos]);
  const [resumen, setResumen] = useState<ResumenSemana | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [generandoResumen, setGenerandoResumen] = useState(false);
  const [vista, setVista] = usePersistedState<'formulario' | 'historial'>(
    'tcd_diario_vista',
    'formulario',
    { validate: (v) => v === 'formulario' || v === 'historial' },
  );

  // Estado del formulario
  const [energia, setEnergia] = useState(5);
  const [cuerpo, setCuerpo] = useState(5);
  const [mente, setMente] = useState(5);
  const [emociones, setEmociones] = useState(5);
  const [logro, setLogro] = useState(() => {
    try { const ses = localStorage.getItem('tcd_sesion_hoy_' + new Date().toISOString().slice(0, 10)); return ses ? `Completé: ${ses}` : ''; } catch { return ''; }
  });
  const [tareas, setTareas] = useState<string[]>([]);
  const [checkeos, setCheckeos] = useState<string[]>([]);
  const [bloqueo, setBloqueo] = useState('');

  const todayStr = toFechaStr(new Date());
  const hoy = new Date();
  const todayEntry = entries.find((e) => e.fecha === todayStr);
  const ayerStr = toFechaStr(new Date(hoy.getTime() - 86400000));
  const ayerEntry = entries.find((e) => e.fecha === ayerStr);

  const historicas = entries.map(toHistorica);
  const racha = rachaActiva(historicas, hoy);
  /** Lo que cerró hoy en su Camino — para no arrancar de una hoja en blanco. */
  const sesionDeHoy = useMemo(() => {
    try {
      const ult = JSON.parse(localStorage.getItem('tcd_ultima_sesion_v1') ?? 'null') as { titulo?: string; fecha?: string } | null;
      const hoyISO = new Date().toISOString().slice(0, 10);
      if (ult?.titulo && (!ult.fecha || ult.fecha.slice(0, 10) === hoyISO)) return ult.titulo;
    } catch { /* noop */ }
    return null;
  }, []);
  const esDomingo = hoy.getDay() === 0;
  const energiaPromedio = energiaPromedio7d(historicas);

  useEffect(() => {
    if (energiaPromedio !== null) {
      localStorage.setItem('tcd_energia_promedio_7d', String(energiaPromedio));
    }
  }, [energiaPromedio]);

  // ─── Cargar datos ─────────────────────────────────────────────────────────
  useEffect(() => {
    try {
      const saved = localStorage.getItem('tcd_diario_v3');
      if (saved) setEntries(JSON.parse(saved));
    } catch { /* noop */ }

    if (!isSupabaseReady() || !supabase || !userId) return;

    setLoading(true);
    Promise.all([
      supabase
        .from('diario_entradas')
        .select('*')
        .eq('user_id', userId)
        .order('fecha', { ascending: false })
        .limit(60),
      supabase
        .from('diario_resumen')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle(),
    ]).then(([{ data: raw }, { data: res }]) => {
      if (raw) {
        const formatted = raw.map(mapRow);
        setEntries(formatted);
        localStorage.setItem('tcd_diario_v3', JSON.stringify(formatted));
      }
      if (res) setResumen(res as ResumenSemana);
    }).finally(() => setLoading(false));
  }, [userId]);

  // ─── Guardar entrada ──────────────────────────────────────────────────────
  const toggle = (list: string[], id: string): string[] =>
    list.includes(id) ? list.filter((x) => x !== id) : [...list, id];

  const handleGuardar = async () => {
    if (!logro.trim()) {
      toast.error('Cuéntanos tu logro de hoy — queda guardado en tu historial.');
      return;
    }
    // Las actividades son opcionales — con la energía y el logro alcanza.

    setSaving(true);
    try {
      const input = { fecha: todayStr, energia, cuerpo, mente, emociones, logro, tareas, checkeos, bloqueo };
      const scoreLocal = calcularScore(input);

      const entradaLocal: EntradaDiario = {
        id: String(Date.now()),
        fecha: todayStr,
        energia, cuerpo, mente, emociones,
        logro: logro.trim(),
        tareas, checkeos,
        bloqueo: bloqueo.trim(),
        score: scoreLocal,
      };

      if (isSupabaseReady() && supabase && userId) {
        const payload = {
              user_id: userId,
              fecha: todayStr,
              energia_nivel: energia,
              diario_cuerpo: cuerpo,
              diario_mente: mente,
              diario_emociones: emociones,
              diario_logro: logro.trim(),
              diario_tareas: tareas,
              diario_checkeos: checkeos,
              diario_bloqueo: bloqueo.trim() || null,
              // back-compat con esquema legacy: columnas previas al diario v3.
              // `respuestas` es NOT NULL en la tabla vieja (cuestionario q1..q5);
              // el diario v3 ya no la usa, pero hay que mandar un valor no-null.
              respuestas: {},
              pensamiento_dominante: logro.trim(),
            };
        const { data: filaCruda } = await guardarFila('diario_entradas', payload, ['user_id', 'fecha']);
        const saved = filaCruda as { id?: string | number; diario_score?: number } | null;
        if (saved) {
          if (saved.id != null) entradaLocal.id = String(saved.id);
          entradaLocal.score = saved.diario_score ?? scoreLocal; // score autoritativo del server
        }
      }

      const actualizadas = [entradaLocal, ...entries.filter((e) => e.fecha !== todayStr)];
      setEntries(actualizadas);
      localStorage.setItem('tcd_diario_v3', JSON.stringify(actualizadas));
      toast.success(`Entrada guardada · Score del día: ${entradaLocal.score}/100`);

      if (esDomingo) await generarResumenSemana(actualizadas);
    } catch (err) {
      // Reportar a Sentry con contexto en vez de tragarse el error en silencio.
      const msg = reportError(err, {
        feature: 'diario-fundador',
        action: 'guardar-entrada',
        extra: { fecha: todayStr, userId },
      });
      toast.error(`Error al guardar: ${msg}`);
    } finally {
      setSaving(false);
    }
  };

  // ─── Resumen semanal (domingo) ────────────────────────────────────────────
  const generarResumenSemana = useCallback(
    async (todasEntradas: EntradaDiario[]) => {
      

      const ahora = new Date();
      const lunes = new Date(ahora);
      lunes.setDate(ahora.getDate() - ahora.getDay() + 1);
      const entradasSemana = todasEntradas.filter((e) => {
        const fecha = new Date(e.fecha + 'T12:00:00');
        return fecha >= lunes;
      });
      if (entradasSemana.length < 1) return;

      setGenerandoResumen(true);
      try {
        const prompt = `Eres el Mentor de "Tu Clínica Digital": master coach especialista en PNL, neurociencia y emprendimiento. Analiza las entradas del Diario del Fundador de esta semana y devuelve un resumen en JSON. Busca: la evolución (energía), los miedos recurrentes (bloqueos), los deseos que asoman (logros), y UN reencuadre de PNL accionable.

ENTRADAS:
${entradasSemana.map((e, i) => `Día ${i + 1} (${e.fecha}): energía ${e.energia}/10 · cuerpo ${e.cuerpo} · mente ${e.mente} · emociones ${e.emociones} · score ${e.score} · logro: "${e.logro}" · bloqueo: "${e.bloqueo || '—'}"`).join('\n')}

Devuelve SOLO este JSON:
{
  "racha": <días consecutivos>,
  "energia_promedio": <decimal 1>,
  "tendencia_energia": "subiendo" | "bajando" | "estable",
  "bloqueo_recurrente": "<si un bloqueo se repite 2+ veces, nombrarlo; si no, null>",
  "emocion_dominante": "<patrón emocional de la semana>",
  "acciones_proxima_semana": ["<acción 1>", "<acción 2>", "<acción 3>"]
}`;

        const texto = await generateText({ tarea: 'guion', prompt });
        const jsonMatch = texto.match(/\{[\s\S]*\}/);
        if (!jsonMatch) throw new Error('No JSON');
        const resumenTexto = JSON.stringify(JSON.parse(jsonMatch[0]));

        if (isSupabaseReady() && supabase && userId) {
          const semanaInicio = toFechaStr(lunes);
          await guardarFila('diario_resumen', { user_id: userId, semana_inicio: semanaInicio, resumen_texto: resumenTexto }, ['user_id', 'semana_inicio']);
          setResumen({ id: '', semana_inicio: semanaInicio, resumen_texto: resumenTexto, created_at: new Date().toISOString() });
        }
        toast.success('Resumen de la semana generado por el Coach.');
      } catch {
        /* nice-to-have, silencioso */
      } finally {
        setGenerandoResumen(false);
      }
    },
    [userId],
  );

  // ─── KPIs (se muestran DESPUÉS de guardar) ────────────────────────────────
  const kpis = todayEntry
    ? {
        indiceBienestar: indiceBienestar(todayEntry),
        focoNegocio: focoNegocio(todayEntry.tareas),
        equilibrio: equilibrioIntegral(todayEntry.cuerpo, todayEntry.mente, todayEntry.emociones),
        consistencia: consistencia7d(historicas, hoy),
        energia7d: energiaPromedio,
        score: todayEntry.score,
        deltaScore: ayerEntry ? todayEntry.score - ayerEntry.score : null,
      }
    : null;

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12 anímate-in fade-in duration-500">

      {/* Header */}
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-light text-cream flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-gold" /> Diario del Fundador
          </h1>
          <p className="text-sm text-cream/75 mt-1 flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5" />
            {new Date().toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' })}
            <span className="text-gold/80 font-medium">· Día {getCurrentDay()} de 90</span>
          </p>
          <p className="text-[11px] text-cream/55 mt-1.5 italic">Este diario alimenta a tu Mentor: lo que escribes hoy es lo que él te devuelve cuando lo necesitas.</p>
          <button type="button" onClick={() => setCronoActivo(true)} className="mt-2 inline-flex items-center gap-2 rounded-full border border-[rgba(232,150,46,0.2)] bg-black/25 px-3 py-1.5">
            <span className="text-[13px]">⏱</span>
            <span className={`text-[13px] font-semibold num-tab ${cronoSegundos === 0 ? 'text-success' : cronoActivo ? 'text-goldhi' : 'text-cream/75'}`}>{Math.floor(cronoSegundos / 60)}:{String(cronoSegundos % 60).padStart(2, '0')}</span>
            <span className="text-[11px] text-cream/55">{cronoSegundos === 0 ? '¿Viste? Ya está. Guarda cuando quieras.' : cronoActivo ? 'tu cierre en 3 minutos' : 'toca si quieres cronometrarlo'}</span>
          </button>
        </div>
        <div className="flex items-center gap-3">
          {energiaPromedio !== null && (
            <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border ${
              energiaPromedio >= 7 ? 'text-success bg-emerald-500/10 border-emerald-500/20' :
              energiaPromedio >= 4 ? 'text-gold bg-gold/10 border-gold/20' :
              'text-danger bg-red-500/10 border-red-500/20'
            }`}>
              <Zap className="w-3.5 h-3.5" />
              <span className="text-sm font-bold">{energiaPromedio}</span>
              <span className="text-[11px] opacity-60">7d</span>
            </div>
          )}
          {racha > 0 && (
            <div className="flex items-center gap-1.5 text-amber-500 bg-amber-500/10 px-3 py-1.5 rounded-xl border border-amber-500/20">
              <Flame className="w-3.5 h-3.5" />
              <span className="text-sm font-bold">{racha} días</span>
            </div>
          )}
          <button
            onClick={() => setVista(vista === 'formulario' ? 'historial' : 'formulario')}
            className="flex items-center gap-1.5 text-cream/75 bg-gold/5 px-3 py-1.5 rounded-xl border border-[rgba(232,150,46,0.12)] hover:bg-gold/10 transition-colors text-sm"
          >
            <History className="w-3.5 h-3.5" />
            Historial
          </button>
        </div>
      </div>

      {/* Resumen semanal */}
      {generandoResumen && (
        <div className="flex items-center gap-2 text-gold bg-gold/10 border border-gold/20 rounded-2xl p-4">
          <Loader2 className="w-4 h-4 anímate-spin" />
          <span className="text-sm">El Coach está analizando tu semana...</span>
        </div>
      )}
      {esDomingo && resumen && (() => {
        try {
          const datos = JSON.parse(resumen.resumen_texto);
          return (
            <div className="card-panel p-5 rounded-2xl border border-violet-500/20 bg-violet-500/5 space-y-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-violet-400" />
                <h3 className="text-sm font-medium text-violet-300">Resumen del Coach — Semana cerrada</h3>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-surface/50 rounded-xl p-3">
                  <p className="text-cream/55 uppercase tracking-wider text-[11px]">Energía promedio</p>
                  <p className="text-cream font-medium mt-0.5">{datos.energia_promedio}/10 — {datos.tendencia_energia}</p>
                </div>
                <div className="bg-surface/50 rounded-xl p-3">
                  <p className="text-cream/55 uppercase tracking-wider text-[11px]">Racha del Diario</p>
                  <p className="text-cream font-medium mt-0.5">{datos.racha} días consecutivos</p>
                </div>
              </div>
              {datos.bloqueo_recurrente && (
                <div className="bg-gold/10 border border-gold/20 rounded-xl p-3">
                  <p className="text-[11px] text-gold uppercase tracking-wider mb-1">Bloqueo recurrente detectado</p>
                  <p className="text-sm text-amber-200">{datos.bloqueo_recurrente}</p>
                </div>
              )}
              {Array.isArray(datos.acciones_proxima_semana) && (
                <div>
                  <p className="text-[11px] text-cream/55 uppercase tracking-wider mb-2">3 acciones para la próxima semana</p>
                  <ul className="space-y-1.5">
                    {datos.acciones_proxima_semana.map((accion: string, i: number) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-cream/80">
                        <span className="text-gold font-bold shrink-0">{i + 1}.</span>
                        {accion}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          );
        } catch { return null; }
      })()}

      {/* S5 — La Rueda de la Vida: el registro del fin, no solo del medio */}


      {/* ── Vista: Formulario ── */}
      {vista === 'formulario' && (
        <>
          {todayEntry ? (
            <div className="space-y-6">
              {/* Confirmación + Score */}
              <div className="card-panel p-6 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
                <div className="flex items-center gap-4 mb-5">
                  <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0 border border-emerald-500/30">
                    <Check className="w-6 h-6 text-success" />
                  </div>
                  <div>
                    <h3 className="text-base font-medium text-success">Entrada del día completada</h3>
                    <p className="text-sm text-success/70 mt-0.5">Tu cierre quedó guardado. Esto es lo que dicen tus números.</p>
                  </div>
                </div>

                {/* Score grande */}
                <div className="flex items-baseline gap-3">
                  <span className="text-5xl font-light text-gold" style={{ fontFamily: 'var(--font-display)' }}>
                    {todayEntry.score}
                  </span>
                  <div>
                    <p className="text-xs text-cream/55">de 100 puntos</p>
                    {kpis?.deltaScore !== null && kpis?.deltaScore !== undefined && (
                      <p className={`text-xs font-medium ${kpis.deltaScore >= 0 ? 'text-success' : 'text-danger'}`}>
                        {kpis.deltaScore >= 0 ? '▲' : '▼'} {Math.abs(kpis.deltaScore)} vs ayer
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* 6 KPIs */}
              {kpis && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <KpiCard label="Índice de bienestar" value={`${kpis.indiceBienestar}`} icon={HeartPulse} tone="green" />
                  <KpiCard label="Foco en negocio" value={`${kpis.focoNegocio}%`} icon={Target} tone={kpis.focoNegocio >= 60 ? 'green' : 'warn'} />
                  <KpiCard label="Consistencia 7d" value={`${kpis.consistencia}%`} icon={TrendingUp} tone="green" />
                  <KpiCard label="Equilibrio integral" value={`${kpis.equilibrio} / 10`} icon={Scale} />
                  <KpiCard label="Promedio energía 7d" value={kpis.energia7d !== null ? `${kpis.energia7d}` : '—'} icon={Zap} tone="green" />
                  <KpiCard label="Racha activa" value={`${racha} días`} icon={Flame} tone="green" />
                </div>
              )}
            </div>
          ) : (
            <div className="card-panel p-6 rounded-2xl space-y-7">
              <div className="flex items-center gap-3">
                {/* La tira de 14 días — tu evolución de un vistazo */}
            {(() => {
              try {
                const raw = JSON.parse(localStorage.getItem('tcd_diario_v3') ?? '[]') as Array<{ fecha?: string; energia?: number }>;
                if (!Array.isArray(raw) || raw.length === 0) return null;
                const porFecha = new Map(raw.map((e) => [String(e.fecha ?? '').slice(0, 10), Number(e.energia ?? 0)]));
                const dias: Array<{ d: string; e: number }> = [];
                for (let k = 13; k >= 0; k--) {
                  const f = new Date(); f.setDate(f.getDate() - k);
                  const key = f.toISOString().slice(0, 10);
                  dias.push({ d: key.slice(8), e: porFecha.get(key) ?? 0 });
                }
                return (
                  <div className="mb-5">
                    <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-cream/55 mb-2">Tus últimos 14 días</p>
                    <div className="flex items-end gap-1.5 h-12">
                      {dias.map((x, i2) => (
                        <div key={i2} className="flex-1 flex flex-col items-center gap-1">
                          <div className="w-full rounded-t" style={{ height: `${Math.max(6, x.e * 10)}%`, background: x.e === 0 ? 'rgba(255,255,255,0.06)' : x.e >= 7 ? '#22C55E' : x.e >= 4 ? '#F4B65C' : '#E8962E', opacity: x.e === 0 ? 1 : 0.9 }} />
                        </div>
                      ))}
                    </div>
                  </div>
                );
              } catch { return null; }
            })()}
            <div className="w-10 h-10 rounded-xl bg-gold/20 flex items-center justify-center border border-gold/30">
                  <BookOpen className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <h2 className="text-base font-medium text-cream">Tu cierre de hoy</h2>
                  <p className="text-xs text-cream/75">Dos toques y una línea. Nada más.</p>
                </div>
              </div>

              {/* Energía general */}
              <div className="bg-surface/30 rounded-xl p-4 border border-[rgba(232,150,46,0.1)]">
                <p className="text-xs font-medium text-cream/80 uppercase tracking-wider flex items-center gap-2 mb-3">
                  <Zap className="w-4 h-4 text-yellow-400" /> ¿Cómo estuvo tu energía hoy?
                </p>
                <div className="grid grid-cols-5 gap-1.5">
                  {NIVELES_ENERGIA.map((n) => {
                    const activo = energia === n.valor;
                    return (
                      <button
                        key={n.valor}
                        type="button"
                        onClick={() => setEnergia(n.valor)}
                        className={`rounded-xl border py-2.5 px-1 transition-all ${activo ? 'border-gold bg-gold/[0.12]' : 'border-cream/10 hover:border-cream/30'}`}
                      >
                        <span className="block text-xl leading-none mb-1">{n.emoji}</span>
                        <span className={`block text-[10px] font-semibold leading-tight ${activo ? 'text-gold' : 'text-cream/55'}`}>{n.palabra}</span>
                      </button>
                    );
                  })}
                </div>
                {ayerEntry && (
                  <p className="text-[11px] text-cream/45 mt-2 text-center">
                    Ayer tuviste <span className="text-success">{ayerEntry.energia}</span>
                    {energia !== ayerEntry.energia && ` — ${energia > ayerEntry.energia ? 'subiste' : 'bajaste'} ${Math.abs(energia - ayerEntry.energia)}`}
                  </p>
                )}
              </div>

              {/* Logro */}
              <div>
                <label className="block text-xs font-medium text-cream/80 mb-2 uppercase tracking-wider flex items-center gap-2">
                  <Award className="w-4 h-4 text-gold" /> Tu victoria de hoy
                </label>
                {sesionDeHoy && !logro.trim() && (
                  <button
                    type="button"
                    onClick={() => setLogro(`Hice mi sesión: ${sesionDeHoy}. `)}
                    className="w-full text-left rounded-xl border border-gold/25 bg-gold/[0.05] px-3 py-2 mb-2 hover:border-gold/50 transition-colors"
                  >
                    <span className="text-[11px] font-bold uppercase tracking-wider text-gold">Hoy hiciste</span>
                    <span className="block text-sm text-cream/85">{sesionDeHoy} — toca para empezar por acá</span>
                  </button>
                )}
                <textarea
                  rows={2}
                  maxLength={LOGRO_MAX_CHARS}
                  placeholder="El avance del que estás orgulloso hoy..."
                  className="w-full bg-black/20 border border-[rgba(232,150,46,0.12)] rounded-xl p-3 text-cream text-sm focus:border-gold/50 focus:ring-1 focus:ring-gold/50 resize-none transition-all placeholder-cream/30"
                  value={logro}
                  onChange={(e) => setLogro(e.target.value)}
                />
                <p className="text-[11px] text-cream/45 mt-1 text-right">{logro.length}/{LOGRO_MAX_CHARS} · queda en tu historial</p>
              </div>

              {/* + más detalle (opcional) — colapsado: el cierre básico son 3 taps */}
              <div>
                <button type="button" onClick={() => setMasDetalle((v) => !v)} className="text-[12px] text-gold/70 hover:text-gold transition-colors">
                  {masDetalle ? '− menos detalle' : '+ más detalle (opcional): dimensiones · actividades · checkeos'}
                </button>
                {masDetalle && (
                  <div className="mt-4 space-y-6">
{/* 3 dimensiones */}
              <div>
                <label className="block text-xs font-medium text-cream/80 mb-3 uppercase tracking-wider">
                  Tus 3 dimensiones — ¿cómo estuvieron cuerpo · mente · emociones?
                </label>
                <div className="space-y-4">
                  {DIMENSIONES.map((dim) => {
                    const val = dim.key === 'cuerpo' ? cuerpo : dim.key === 'mente' ? mente : emociones;
                    const set = dim.key === 'cuerpo' ? setCuerpo : dim.key === 'mente' ? setMente : setEmociones;
                    return (
                      <div key={dim.key} className="flex items-center gap-3">
                        <div className="flex items-center gap-2 w-28 shrink-0">
                          <dim.icon className="w-4 h-4 text-gold" />
                          <span className="text-xs text-cream/70">{dim.label}</span>
                        </div>
                        <div className="flex-1"><Escala10 valor={val} onChange={set} color={colorDimension} /></div>
                        <span className="text-sm font-medium text-cream w-5 text-right">{val}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* ¿En qué estuviste? */}
              <div>
                <label className="block text-xs font-medium text-cream/80 mb-2 uppercase tracking-wider">
                  ¿En qué estuviste hoy?
                </label>
                <div className="flex flex-wrap gap-2">
                  {TAREAS_TAGS.map((tag) => {
                    const on = tareas.includes(tag.id);
                    return (
                      <button
                        key={tag.id}
                        type="button"
                        onClick={() => setTareas((prev) => toggle(prev, tag.id))}
                        className={`text-xs px-3 py-2 rounded-lg border transition-all ${
                          on
                            ? 'border-gold/40 text-cream bg-gold/10'
                            : 'border-white/8 text-cream/55 hover:bg-white/5'
                        }`}
                      >
                        {tag.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Bloqueo */}
              <div>
                <label className="block text-xs font-medium text-cream/80 mb-2 uppercase tracking-wider">
                  Bloqueos <span className="text-cream/45 normal-case">(opcional)</span>
                </label>
                <textarea
                  rows={2}
                  maxLength={BLOQUEO_MAX_CHARS}
                  placeholder="¿Algo te frenó hoy? Técnico, emocional, externo. No hay respuesta mala."
                  className="w-full bg-black/20 border border-dashed border-[rgba(232,150,46,0.12)] rounded-xl p-3 text-cream text-sm focus:border-gold/50 focus:ring-1 focus:ring-gold/50 resize-none transition-all placeholder-cream/30"
                  value={bloqueo}
                  onChange={(e) => setBloqueo(e.target.value)}
                />
              </div>

              {/* Checkeos rápidos */}
              <div className="bg-surface/30 rounded-xl p-4 border border-[rgba(232,150,46,0.1)]">
                <div className="flex items-center gap-2 mb-3">
                  <HeartPulse className="w-4 h-4 text-success" />
                  <span className="text-xs font-medium text-cream/80 uppercase tracking-wider">Checkeos rápidos</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {CHECKEOS_CHIPS.map((chip) => {
                    const on = checkeos.includes(chip.id);
                    const Icon = CHECKEO_ICONS[chip.id] ?? Check;
                    const onColor = chip.positivo
                      ? 'border-success/30 text-success bg-success/5'
                      : 'border-[#E09040]/30 text-[#E09040] bg-[#E09040]/5';
                    return (
                      <button
                        key={chip.id}
                        type="button"
                        onClick={() => setCheckeos((prev) => toggle(prev, chip.id))}
                        className={`flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg border transition-all ${
                          on ? onColor : 'border-white/8 text-cream/35 hover:bg-white/5'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        {chip.label}
                      </button>
                    );
                  })}
                </div>
              </div>

                                </div>
                )}
              </div>

              {/* Guardar */}
              <button
                onClick={handleGuardar}
                disabled={saving}
                className="w-full py-3.5 rounded-xl bg-gold hover:bg-goldhi disabled:opacity-50 text-[#0A0806] font-semibold tracking-wide transition-all flex justify-center items-center gap-2"
              >
                {saving ? (
                  <><Loader2 className="w-4 h-4 anímate-spin" /> Guardando...</>
                ) : (
                  <><Send className="w-4 h-4" /> Guardar entrada del día</>
                )}
              </button>
              <p className="text-[11px] text-cream/45 text-center -mt-3">
                {racha > 0
                  ? `Llevas ${racha} ${racha === 1 ? 'día' : 'días'} seguidos. Esto es lo que tu Mentor va a recordar mañana.`
                  : 'Dos minutos. Esto es lo que tu Mentor va a recordar mañana.'}
              </p>
            </div>
          )}
        </>
      )}

      {/* ── Vista: Historial ── */}
      {vista === 'historial' && (
        <div className="space-y-4">
          {loading && entries.length === 0 && (
            <div className="flex items-center gap-2 text-cream/55 text-sm">
              <Loader2 className="w-4 h-4 anímate-spin" /> Cargando historial...
            </div>
          )}
          {entries.length === 0 && !loading && (
            <p className="text-center text-cream/55 text-sm py-12">Aún no hay entradas en el Diario.</p>
          )}
          {entries.map((entrada) => (
            <div key={entrada.id} className="card-panel p-5 rounded-2xl border-l-4 border-l-gold/50 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gold font-medium">
                  {new Date(entrada.fecha + 'T12:00:00').toLocaleDateString('es-AR', {
                    weekday: 'long', day: 'numeric', month: 'long',
                  })}
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-2 py-1 rounded-full bg-gold/15 text-gold">
                    {entrada.score}/100
                  </span>
                  <span className={`text-xs font-bold px-2 py-1 rounded-full ${
                    entrada.energia >= 7 ? 'bg-emerald-500/15 text-success' :
                    entrada.energia >= 4 ? 'bg-gold/15 text-gold' :
                    'bg-red-500/15 text-danger'
                  }`}>
                    <Zap className="w-3 h-3 inline" /> {entrada.energia}/10
                  </span>
                </div>
              </div>

              {entrada.logro && (
                <div>
                  <span className="text-cream/45 uppercase tracking-wider text-[11px]">Logro</span>
                  <p className="text-cream/80 mt-0.5 text-sm">{entrada.logro}</p>
                </div>
              )}

              <div className="flex gap-3 text-[11px] text-cream/65">
                <span>Cuerpo {entrada.cuerpo}</span>
                <span>Mente {entrada.mente}</span>
                <span>Emociones {entrada.emociones}</span>
              </div>

              {entrada.bloqueo && (
                <div>
                  <span className="text-cream/45 uppercase tracking-wider text-[11px]">Bloqueo</span>
                  <p className="text-cream/70 mt-0.5 text-sm">{entrada.bloqueo}</p>
                </div>
              )}

              {entrada.tareas.length > 0 && (
                <div className="flex gap-1.5 flex-wrap">
                  {entrada.tareas.map((id) => {
                    const tag = TAREAS_TAGS.find((t) => t.id === id);
                    return tag ? (
                      <span key={id} className="text-[11px] bg-gold/5 px-2 py-1 rounded-full text-cream/75">
                        {tag.label}
                      </span>
                    ) : null;
                  })}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
