import { resumenOrigenParaMentor } from '../lib/origen';
import { resumenRuedaParaMentor } from '../lib/rueda';
import { planDe, TOPE_MENTOR_BLANCO, TOPE_MENTOR_SEMANAL, usosSemana, consumirUso } from '../lib/planes';
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { safeGet } from '../lib/safeStorage';
import { Send, Bot, RefreshCw, Sparkles, Zap } from 'lucide-react';
import { streamText } from '../lib/aiProvider';
import Markdown from 'react-markdown';
import { toast } from 'sonner';
import {
  AttachButton,
  AttachmentsPreviewStrip,
} from '../components/ChatAttachmentsBar';
import {
  attachmentsToContext,
  buildAttachmentsFromDataTransfer,
  type ChatAttachment,
} from '../lib/chatAttachments';
import {
  buildCoachSystemPrompt,
  detectarContextoConversacion,
  loadCoachExtraContext,
} from '../lib/coachPrompt';
import {
  getUserKnowledgeBase,
  getUserKnowledgeBaseSync,
} from '../lib/userKnowledgeBase';
import {
  supabase,
  isSupabaseReady,
  agentSkillProgressRepo,
  type PilarId,
  type HojaDeRutaItem,
} from '../lib/supabase';
import {
  loadCoachState,
  saveCoachMessages,
  rotateSummaryIfNeeded,
  resetCoach,
  type CoachConversationMessage,
} from '../lib/coachConversation';
import {
  getCoachQuickReplies,
  type CoachQuickReplyContext,
} from '../lib/coachQuickReplies';
import { AGENTES, NIVEL_NOMBRE } from '../lib/agents';

type Message = CoachConversationMessage;

function buildInitialMessage(): Message {
  const profile = safeGet<{ fecha_inicio?: string; nombre?: string; [k: string]: unknown }>('tcd_profile', {});
  const dInicio = profile.fecha_inicio ? new Date(profile.fecha_inicio) : new Date();
  const diff = Math.floor((Date.now() - dInicio.getTime()) / (1000 * 60 * 60 * 24));
  const semanaActual = Math.max(1, Math.min(13, Math.floor(diff / 7) + 1));
  const nombre = profile.nombre || 'Fundadora';

  const diary = safeGet<{ respuestas?: { cuello?: string; foco?: string } }[]>('tcd_diary_weekly', []);
  const last = diary.length > 0 ? diary[0].respuestas : null;

  // El wow del día 1: si es su primera semana y hay diagnóstico, el espejo va primero
  const dxRaw = safeGet<Record<string, string>>('tcd_diagnostico', {});
  const freno = dxRaw.freno || '';
  if (semanaActual === 1 && freno) {
    return {
      role: 'assistant',
      content: `${nombre}, antes de tu primera sesión quiero decirte algo.\n\nEn tu diagnóstico escribiste que lo que más te frena es: _"${freno}"_.\n\nQuiero que sepas dos cosas. La primera: eso que escribiste no es tu problema — es el síntoma. El problema real lo vamos a encontrar esta semana, y probablemente no es lo que piensas.\n\nLa segunda: el día 4 de esta semana vas a hacer algo físico con eso. No te adelanto más.\n\nTu primera sesión te espera en El Camino. Es corta. Empieza hoy — el impulso del día 1 vale oro. 🥋`,
    } as Message;
  }
  let msg = `Hola ${nombre}. Empezamos la **Semana ${semanaActual}**.\n\n`;
  if (last && last.cuello) {
    msg += `Noté en tu último check-in que tu foco es _"${last.foco}"_, pero estás frenada por: _"${last.cuello}"_.\n\n`;
  }
  msg += `¿Qué acción atómica vamos a tomar ahora mismo para destrabar esto y avanzar?`;
  return { role: 'assistant', content: msg };
}

function getPilarActivo(perfil: Record<string, unknown> | null): PilarId | null {
  if (!perfil) return null;
  const num = perfil.pilar_actual;
  if (typeof num !== 'number') return null;
  // Mapeo aproximado: 1→P1, 2→P2,... 9→P9A (asumimos current goes 0-11)
  if (num <= 0) return 'P0';
  if (num >= 1 && num <= 8) return `P${num}` as PilarId;
  if (num === 9) return 'P9A';
  if (num === 10) return 'P9B';
  if (num === 11) return 'P9C';
  if (num === 12) return 'P10';
  if (num === 13) return 'P11';
  return null;
}

function daysSince(iso: string | null | undefined): number {
  if (!iso) return 999;
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return 999;
  return Math.floor((Date.now() - t) / 86400000);
}

export default function Coach({ userId, perfil }: { userId?: string; perfil?: Partial<import('../lib/supabase').Profile> }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [cargandoEstado, setCargandoEstado] = useState(true);
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const [uploadingAttachment, setUploadingAttachment] = useState(false);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const knowledgeBaseRef = useRef<string>(getUserKnowledgeBaseSync());
  const supabaseProfileRef = useRef<Record<string, unknown> | null>(null);

  // Estado del Coach IA · sumario + last_summary_at_msg_count viven en DB
  const summaryRef = useRef<string | null>(null);
  const lastSummaryAtRef = useRef<number>(0);
  const nivelesEntrenadoresRef = useRef<Record<string, number>>({});
  const alcanzoNivel4Ref = useRef<boolean>(false);
  // Estado real de El Camino · alimenta el system prompt para que el
  // Coach sepa qué metas ★ están hechas y no las sugiera de nuevo.
  const tareasHojaDeRutaRef = useRef<HojaDeRutaItem[]>([]);

  // ─── Carga inicial: state · perfil · niveles entrenadores ──────────────────
  useEffect(() => {
    let cancelado = false;
    async function init() {
      setCargandoEstado(true);
      try {
        if (userId) {
          const state = await loadCoachState(userId);
          if (cancelado) return;
          summaryRef.current = state.summary;
          lastSummaryAtRef.current = state.lastSummaryAtMsgCount;
          setMessages(state.messages.length > 0 ? state.messages : [buildInitialMessage()]);

          const skillRows = await agentSkillProgressRepo.loadAll(userId);
          if (cancelado) return;
          const nivByAgentId: Record<string, number> = {};
          let nivel4Alcanzado = false;
          for (const r of skillRows) {
            nivByAgentId[r.agent_id] = r.current_level;
            const last = r.last_practice_at ? new Date(r.last_practice_at).getTime() : 0;
            const sieteDias = Date.now() - 7 * 86400000;
            if (r.current_level === 4 && last > sieteDias) {
              nivel4Alcanzado = true;
            }
          }
          nivelesEntrenadoresRef.current = nivByAgentId;
          alcanzoNivel4Ref.current = nivel4Alcanzado;
        } else {
          // Sin userId · fallback localStorage (modo demo · offline).
          const raw = localStorage.getItem('tcd_coach_messages_v2');
          const arr = raw ? (JSON.parse(raw) as Message[]) : [];
          setMessages(arr.length > 0 ? arr : [buildInitialMessage()]);
        }
      } catch {
        setMessages([buildInitialMessage()]);
      } finally {
        if (!cancelado) setCargandoEstado(false);
      }
    }
    init();
    return () => {
      cancelado = true;
    };
  }, [userId]);

  // ─── Auto-scroll ───────────────────────────────────────────────────────────
  useEffect(() => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop =
        messagesContainerRef.current.scrollHeight;
    }
  }, [messages]);

  // ─── Knowledge base ────────────────────────────────────────────────────────
  useEffect(() => {
    getUserKnowledgeBase(userId).then((kb) => {
      knowledgeBaseRef.current = kb;
    });
  }, [userId]);

  // ─── Perfil fresco desde Supabase ──────────────────────────────────────────
  useEffect(() => {
    if (!userId || !isSupabaseReady() || !supabase) return;
    supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle()
      .then(({ data }) => {
        if (data) supabaseProfileRef.current = data as Record<string, unknown>;
      });
  }, [userId]);

  // ─── Hoja de Ruta fresca desde Supabase (estado real de las metas) ────────
  useEffect(() => {
    if (!userId || !isSupabaseReady() || !supabase) return;
    supabase
      .from('hoja_de_ruta')
      .select('*')
      .eq('usuario_id', userId)
      .then(({ data }) => {
        if (data) tareasHojaDeRutaRef.current = data as HojaDeRutaItem[];
      });
  }, [userId]);

  // ─── Quick replies dinámicos (recalcular cuando cambia el perfil o niveles)
  const quickReplies = useMemo(() => {
    const perfil = supabaseProfileRef.current ?? {};
    const lastDiaryRaw = localStorage.getItem('tcd_diary_weekly');
    let diasSinEntrar = 0;
    try {
      const arr = lastDiaryRaw ? JSON.parse(lastDiaryRaw) : [];
      diasSinEntrar = arr[0]?.fecha ? daysSince(arr[0].fecha) : 999;
    } catch {
      /* noop */
    }
    const lastMetricsAt =
      (perfil as { ultima_metrica_at?: string }).ultima_metrica_at ?? null;
    const ctx: CoachQuickReplyContext = {
      pilarActivo: getPilarActivo(perfil),
      diasAtraso:
        typeof (perfil as { dias_atraso?: number }).dias_atraso === 'number'
          ? ((perfil as { dias_atraso?: number }).dias_atraso ?? 0)
          : 0,
      diasSinEntrar,
      alcanzoNivel4EstaSemana: alcanzoNivel4Ref.current,
      diasSinMetricas: daysSince(lastMetricsAt),
    };
    return getCoachQuickReplies(ctx);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages.length, cargandoEstado]);

  const resetConversation = useCallback(async () => {
    const fresh = [buildInitialMessage()];
    setMessages(fresh);
    summaryRef.current = null;
    lastSummaryAtRef.current = 0;
    if (userId) {
      try {
        await resetCoach(userId);
        await saveCoachMessages(userId, fresh);
      } catch {
        /* silencioso */
      }
    } else {
      localStorage.setItem('tcd_coach_messages_v2', JSON.stringify(fresh));
    }
  }, [userId]);

  const [guardadoOk, setGuardadoOk] = useState(false);
  const persist = useCallback(
    async (msgs: Message[]) => {
      if (userId) {
        try {
          await saveCoachMessages(userId, msgs);
          setGuardadoOk(true);
          setTimeout(() => setGuardadoOk(false), 2500);
        } catch {
          /* silencioso */
        }
      } else {
        localStorage.setItem('tcd_coach_messages_v2', JSON.stringify(msgs));
        setGuardadoOk(true);
        setTimeout(() => setGuardadoOk(false), 2500);
      }
    },
    [userId],
  );

  const intentarRotarSummary = useCallback(
    async (msgsAhora: Message[]) => {
      if (!userId) return;
      const result = await rotateSummaryIfNeeded(userId, {
        messages: msgsAhora,
        summary: summaryRef.current,
        lastSummaryAtMsgCount: lastSummaryAtRef.current,
      });
      if (result) {
        summaryRef.current = result.summary;
        lastSummaryAtRef.current = result.msgCount;
      }
    },
    [userId],
  );

  const handleSend = useCallback(
    async (text: string) => {
      const hasAttachments = attachments.length > 0;
      if ((!text.trim() && !hasAttachments) || isTyping) return;

      // ═══ El tope de los 5 días: 30 mensajes, cierre elegante ═══
      // ─── La escasez que enseña: 10 preguntas de maestro por semana (planes del camino) ───
      if (planDe(perfil) !== 'blanco') {
        if (usosSemana('mentor') >= TOPE_MENTOR_SEMANAL) {
          setMessages((prev) => [...prev, { role: 'user', content: text }, {
            role: 'assistant',
            content: 'Usaste tus ' + TOPE_MENTOR_SEMANAL + ' preguntas de maestro de esta semana — bien usadas valen oro. El lunes se renuevan. Mientras tanto, el dojo sigue abierto: tu sesión de hoy te espera en El Camino, y si algo se traba en plena sesión, ahí estoy contigo adentro.',
          }]);
          setInput('');
          return;
        }
        consumirUso('mentor');
      }
      if (planDe(perfil) === 'blanco') {
        let usados = 0;
        try { usados = parseInt(localStorage.getItem('tcd_mentor_blanco_msgs') ?? '0', 10) || 0; } catch { /* noop */ }
        if (usados >= TOPE_MENTOR_BLANCO) {
          setMessages((prev) => [...prev, {
            role: 'assistant' as const,
            content: 'Llegamos al límite de conversaciones de tus 5 días. No es un adiós: del otro lado seguimos juntos cada semana, con todo tu historial y con las sesiones que todavía no abriste. En HOY tienes el botón para seguir tu camino — un toque y retomamos exactamente donde quedamos.',
          }]);
          return;
        }
        try { localStorage.setItem('tcd_mentor_blanco_msgs', String(usados + 1)); } catch { /* noop */ }
      }

      const sentAttachments = attachments;
      setAttachments([]);
      setInput('');

      // Texto visible para el usuario · etiquetas inline con los archivos adjuntos
      const visibleText = hasAttachments
        ? `${text.trim() || '(adjuntos para analizar)'}\n\n${sentAttachments
            .map((a) =>
              a.kind === 'image' ? `📎 ${a.fileName} (imagen)` : `📎 ${a.fileName}`,
            )
            .join('\n')}`
        : text;

      const conUsuario: Message[] = [
        ...messages,
        { role: 'user', content: visibleText },
      ];
      setMessages(conUsuario);
      setIsTyping(true);

      try {
        // Contexto enriquecido con descripciones de imagenes + texto de archivos
        const attachmentsCtx = hasAttachments
          ? await attachmentsToContext(sentAttachments)
          : '';
        const promptText = `${attachmentsCtx}${text.trim() || 'Por favor, analiza los archivos/imagenes adjuntas.'}`;

        setMessages((prev) => [...prev, { role: 'assistant', content: '' }]);

        // Para el provider mandamos el promptText enriquecido en el ultimo turno
        const aiMessages = [
          ...messages.map((m) => ({
            role: m.role === 'assistant' ? 'assistant' : 'user',
            content: m.content,
          })),
          { role: 'user', content: promptText },
        ];

        const extraCtx = detectarContextoConversacion(text);
        const coachExtra = loadCoachExtraContext();
        const localPerfil = safeGet<{ fecha_inicio?: string; nombre?: string; [k: string]: unknown }>('tcd_profile', {});
        const perfil = { ...localPerfil, ...(supabaseProfileRef.current ?? {}) };

        // Texto resumido de niveles por entrenador · para el system prompt
        const nivelesTexto = AGENTES.map((a) => {
          const lvl = nivelesEntrenadoresRef.current[a.id] ?? 1;
          return `${a.titulo.split(' ·')[0]}: Nivel ${lvl} (${NIVEL_NOMBRE[lvl as 1 | 2 | 3 | 4]})`;
        }).join(' · ');

        const systemPrompt = buildCoachSystemPrompt({
          perfil,
          ...extraCtx,
          ...coachExtra,
          baseDeConocimiento: knowledgeBaseRef.current || undefined,
          coachHistorySummary: summaryRef.current ?? undefined,
          nivelesEntrenadoresTexto: nivelesTexto,
          tareasHojaDeRuta: tareasHojaDeRutaRef.current,
        }) + resumenRuedaParaMentor() + resumenOrigenParaMentor();

        let fullResponse = '';
        for await (const chunk of streamText({ feature: 'mentor', tarea: 'chat',
          systemInstruction: systemPrompt,
          messages: aiMessages,
        })) {
          fullResponse += chunk;
          setMessages((prev) => {
            const next = [...prev];
            next[next.length - 1] = { ...next[next.length - 1], content: fullResponse };
            return next;
          });
        }

        const finales: Message[] = [
          ...conUsuario,
          { role: 'assistant', content: fullResponse },
        ];
        await persist(finales);
        await intentarRotarSummary(finales);
      } catch {
        toast.error('El Mentor no pudo responder. Vuelve a intentarlo en un momento.');
        setMessages((prev) => {
          const next = [...prev];
          next[next.length - 1] = {
            ...next[next.length - 1],
            content: 'Hubo un error de red. ¿Podrías repetirme eso?',
          };
          return next;
        });
      } finally {
        setIsTyping(false);
      }
    },
    [attachments, isTyping, messages, persist, intentarRotarSummary, perfil],
  );

  const handlePaste = useCallback(
    async (e: React.ClipboardEvent<HTMLInputElement>) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      // Solo interceptamos si hay archivos · si es texto puro dejamos paste por defecto
      let hasFile = false;
      for (let i = 0; i < items.length; i++) {
        if (items[i].kind === 'file') {
          hasFile = true;
          break;
        }
      }
      if (!hasFile) return;
      e.preventDefault();
      setUploadingAttachment(true);
      try {
        const nuevos = await buildAttachmentsFromDataTransfer(
          e.clipboardData,
          (msg) => toast.error(msg),
        );
        if (nuevos.length > 0) {
          setAttachments((prev) => [...prev, ...nuevos]);
          toast.success(
            nuevos.length === 1
              ? 'Captura adjuntada'
              : `${nuevos.length} adjuntos agregados`,
          );
        }
      } finally {
        setUploadingAttachment(false);
      }
    },
    [],
  );

  const avatarUrl = localStorage.getItem('tcd_avatar') || '';
  const profile = (() => {
    try {
      return safeGet<{ fecha_inicio?: string; nombre?: string; [k: string]: unknown }>('tcd_profile', {});
    } catch {
      return {};
    }
  })();
  const userInitial = (profile.nombre || 'U').charAt(0).toUpperCase();

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col card-panel rounded-2xl overflow-hidden animate-in fade-in duration-500 border border-gold/10">
      <div className="p-5 border-b border-[rgba(232,150,46,0.10)] bg-gold/[0.03] flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-gold/20 flex items-center justify-center border border-gold/30">
            <Bot className="w-5 h-5 text-gold" />
          </div>
          <img
            src="/javo.jpg"
            alt="Javo"
            className="w-9 h-9 rounded-full object-cover border border-gold/40 shrink-0"
            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
          />
          <div>
            <h2 className="text-sm font-semibold text-white tracking-widest uppercase mb-0.5">
              Mentor IA
            </h2>
            <p className="text-[11px] text-white/65 font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-success" /> Tu guía del camino · conoce tu ADN completo
              {guardadoOk && <span className="text-success normal-case font-semibold tracking-normal transition-opacity">· Guardado ✓</span>}
            </p>
          </div>
        </div>
        <button
          onClick={resetConversation}
          title="Reiniciar conversación"
          className="w-8 h-8 rounded-lg hover:bg-gold/10 flex items-center justify-center text-white/55 hover:text-white transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide"
      >
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border overflow-hidden ${
                msg.role === 'assistant'
                  ? 'bg-gold/15 text-gold border-gold/40 ring-2 ring-gold/10'
                  : 'bg-white/5 text-white/75 border-white/10'
              }`}
            >
              {msg.role === 'assistant' ? (
                <span className="text-[13px] font-bold" style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic' }}>M</span>
              ) : avatarUrl ? (
                <img loading="lazy" src={avatarUrl} alt="" className="w-full h-full object-cover" />
              ) : (
                <span className="text-xs font-bold text-white">{userInitial}</span>
              )}
            </div>

            {msg.role === 'assistant' && !msg.content.includes('```') ? (
              /* El Mentor humano: burbujas separadas por párrafo — conversación, no documento */
              <div className="max-w-[85%] flex flex-col gap-2">
                {msg.content.split(/\n\n+/).filter(Boolean).map((parte, pi) => (
                  <div key={pi} className="bg-surface text-white/90 rounded-[20px] rounded-tl-md border border-[rgba(232,150,46,0.10)] px-5 py-3.5 fade-rise" style={{ boxShadow: 'var(--shadow-card)', animationDelay: `${Math.min(pi * 120, 600)}ms` }}>
                    <div className="prose prose-invert prose-sm max-w-none text-[13px] leading-relaxed prose-p:my-0 prose-strong:text-goldhi prose-li:my-0.5">
                      <Markdown>{parte}</Markdown>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
            <div
              className={`max-w-[85%] rounded-2xl p-5 ${
                msg.role === 'user'
                  ? 'bg-gold text-ink rounded-tr-sm shadow-lg'
                  : 'card-panel bg-surface text-white/90 rounded-tl-sm border border-[rgba(232,150,46,0.10)]'
              }`}
            >
              {msg.role === 'user' ? (
                <p className="text-[13px] leading-relaxed whitespace-pre-wrap">
                  {msg.content}
                </p>
              ) : (
                <div className="text-[13px] leading-relaxed prose prose-invert max-w-none prose-p:leading-relaxed prose-pre:bg-black/50 prose-li:my-1 prose-a:text-gold">
                  {msg.content ? (
                    <Markdown>{msg.content}</Markdown>
                  ) : (
                    <span className="flex gap-1.5 items-center py-1">
                      <span
                        className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce"
                        style={{ animationDelay: '0ms' }}
                      />
                      <span
                        className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce"
                        style={{ animationDelay: '150ms' }}
                      />
                      <span
                        className="w-1.5 h-1.5 rounded-full bg-gold animate-bounce"
                        style={{ animationDelay: '300ms' }}
                      />
                    </span>
                  )}
                </div>
              )}
            </div>
            )}
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-[rgba(232,150,46,0.10)] bg-black/20">
        {quickReplies.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {quickReplies.map((qr) => (
              <button
                key={qr.id}
                onClick={() => handleSend(qr.label)}
                disabled={isTyping}
                className="px-3.5 py-2 rounded-xl border border-[rgba(232,150,46,0.22)] bg-gradient-to-b from-gold/10 to-transparent hover:from-gold/20 hover:border-gold/40 text-xs text-cream/85 font-medium transition-all disabled:opacity-50 flex items-center gap-1.5 active:scale-[0.98]"
              >
                {qr.icon && <span className="text-[11px]">{qr.icon}</span>}
                {qr.label}
              </button>
            ))}
          </div>
        )}

        <AttachmentsPreviewStrip
          attachments={attachments}
          onChange={setAttachments}
          uploading={uploadingAttachment}
        />

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend(input);
          }}
          className="relative flex items-center gap-2"
        >
          <AttachButton
            attachments={attachments}
            onChange={setAttachments}
            onUploadingChange={setUploadingAttachment}
            onError={(msg) => toast.error(msg)}
            disabled={isTyping || cargandoEstado}
          />
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onPaste={handlePaste}
            disabled={isTyping || cargandoEstado}
            placeholder={
              isTyping
                ? 'Tu coach está conectando ideas...'
                : 'Cuéntale dónde estás — tu Mentor conoce tu camino...'
            }
            className="flex-1 bg-white/5 border border-[rgba(232,150,46,0.12)] rounded-xl py-3.5 pl-4 pr-12 text-sm text-white placeholder-white/30 focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/50 transition-all disabled:opacity-50 shadow-inner"
          />
          <button
            type="submit"
            disabled={
              (!input.trim() && attachments.length === 0) ||
              isTyping ||
              cargandoEstado ||
              uploadingAttachment
            }
            className="absolute right-2 w-9 h-9 rounded-lg bg-gold hover:bg-goldhi disabled:opacity-50 flex items-center justify-center text-ink transition-colors"
          >
            <Send className="w-4 h-4 ml-1" />
          </button>
        </form>
      </div>
    </div>
  );
}
